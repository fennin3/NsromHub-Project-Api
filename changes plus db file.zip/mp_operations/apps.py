from django.apps import AppConfig


class MpOperationsConfig(AppConfig):
    name = 'mp_operations'
