from django.apps import AppConfig


class SuperadminOperationsConfig(AppConfig):
    name = 'superadmin_operations'
